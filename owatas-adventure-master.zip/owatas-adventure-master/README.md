# 人生ｵﾜﾀ＼(^o^)／の大冒険 for HTML5

[人生ｵﾜﾀ＼(^o^)／の大冒険 for Flash](http://king-soukutu.com/flash/owata.html) の HTML5 版クローン。

## ライブラリー

- [phina.js](https://github.com/phinajs/phina.js)

## 効果音

- [ティウンティウン](http://developer.bokunatu.com/dbf2/profile.cgi?key=%8C%F8%89%CA%89%B9&type=or&label=2&hor=1&max=300&tpl=small&type=all&sort_item=1&sort_mode=1)
